package org.springframework.samples.petclinic.utility;

import static org.junit.jupiter.api.Assertions.*;

// todo
class PetTimedCacheTest {
}
