package org.springframework.samples.petclinic.owner;

import org.junit.Test;
import org.springframework.samples.petclinic.utility.PetTimedCache;
import org.springframework.samples.petclinic.utility.SimpleDI;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import javax.validation.constraints.AssertTrue;

import static org.junit.Assert.*;
import java.util.*;


@RunWith(Parameterized.class)
public class PetServiceTest {

	public int petId;
	public Pet pet;
	public PetService petService = new PetService(new PetTimedCache(new Pet));

	public PetServiceTest(Integer id, Pet pet){
		petService.savePet(pet, new Owner());
		this.pet = pet;
		this.petId = id;
	}
	@Parameters public static Collection<Object[]>parameters(){
		List<Object[]> params = new ArrayList<>();
		Pet pet = null;
		pet = new Pet();
		pet.setId((Integer)1376);
		params.add(new Object[]{1376,pet});
		pet = new Pet();
		pet.setId(1414);
		params.add(new Object[]{1414,pet});
		pet = new Pet();
		pet.setId(13);
		params.add(new Object[]{13,pet});
		return params;
	}
	@Test public void testFindPets(){
		Assert.assertEquals(petService.findPet(petId), pet);
	}

}
