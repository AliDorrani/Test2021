package org.springframework.samples.petclinic.owner;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.*;

import io.cucumber.java.eo.Se;
import org.junit.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import java.util.*;

import org.junit.jupiter.api.Test;

class OwnerTests {

	private Owner owner;
	private Owner setOwner;
	private Set<Pet> petSet1;
	private Set<Pet> petSet2;

	@BeforeEach
	public void setUp() {
		owner = new Owner();
		setOwner = new Owner();
		owner.setAddress("hello");
		owner.setCity("Tehran");
		owner.setTelephone("09122800541");
		Pet pet1 = new Pet();
		Pet pet2 = new Pet();
		Pet pet3 = new Pet();
		petSet1 = new HashSet<>();
		petSet1.add(pet1);
		petSet1.add(pet2);
		petSet1.add(pet3);
		owner.setPetsInternal(petSet1);
		Pet pet4 = new Pet();
		Pet pet5 = new Pet();
		Pet pet6 = new Pet();
		petSet2 = new HashSet<>();
		petSet2.add(pet4);
		petSet2.add(pet5);
		petSet2.add(pet6);
		owner.setPetsInternal(petSet1);
		owner.setFirstName("Ali");
		owner.setLastName("Imani");
		owner.setId(1376);
	}

	@Test
	public void testGetAddress() {
		Assertions.assertEquals("hello", owner.getAddress());
	}
	@Test
	public void testGetCity(){
		Assertions.assertEquals("Tehran", owner.getCity());
	}
	@Test
	public void testGetTelephone() {
		Assertions.assertEquals("09122800541", owner.getTelephone());
	}
	@Test
	public void testGetPetsInternal() {
		Assertions.assertEquals(petSet1, owner.getPetsInternal());
	}
	@Test
	public void testGetFirstName(){
		Assertions.assertEquals("Ali", owner.getFirstName());
	}
	@Test
	public void testGetLastName(){
		Assertions.assertEquals("Imani", owner.getLastName());
	}
	@Test
	public void testGetId(){
		Assertions.assertEquals(1376, owner.getId());
	}
	@Test
	public void testSetAddress(){
		setOwner.setAddress("No2, NasimDanesh Complex");
		Assertions.assertEquals("No2, NasimDanesh Complex",setOwner.getAddress());
	}
	@Test
	public void testSetCity(){
		setOwner.setCity("Ardabil");
		Assertions.assertEquals("Ardabil", setOwner.getCity());
	}

	@Test
	public void testSetTelephone(){
		setOwner.setTelephone("09381929725");
		Assertions.assertEquals("09381929725",setOwner.getTelephone());
	}
	@Test
	public void testSetFirstName(){
		setOwner.setFirstName("Mohsen");
		Assertions.assertEquals("Mohsen", setOwner.getFirstName());
	}

	@Test
	public void testSetLastName(){
		setOwner.setLastName("Dorrani");
		Assertions.assertEquals("Dorrani",setOwner.getLastName());
	}
	@Test
	public void testSetId(){
		setOwner.setId(34);
		Assertions.assertEquals(34, setOwner.getId());
	}
	@Test
	public void testSetPetsInternal(){
		setOwner.setPetsInternal(petSet2);
		Assertions.assertEquals(petSet2, setOwner.getPetsInternal());
	}
	@AfterEach
	public void tearDown() {
		setOwner = null;
		owner = null;

	}
}
