package org.springframework.samples.petclinic.owner;

import org.junit.jupiter.api.Test;
import org.springframework.samples.petclinic.visit.Visit;

import java.time.LocalDate;

class PetTest {

	// todo
}
